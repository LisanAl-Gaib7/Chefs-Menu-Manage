# Chef's Menu Manager — Part 2 (Build the App)

A working React Native + TypeScript app for the Chef's Menu Manager,
built from the plan in Part 1 (POE).

## What it does

- **Menu list screen (home):** shows every dish that's been added, in a
  scrollable list, with an item count and an empty-state message.
- **Add Menu Item screen:** a form for Dish Name, Description, Course
  (dropdown) and Price. Tap the orange **+** button on the home screen to
  open it.
- Required-field validation, inline error messages, a "saved successfully"
  confirmation, and the list updates immediately when a new dish is added.

This covers Part 2's four requirements: UI, capturing info, displaying
items, and UX polish (validation/errors/confirmation/empty state). Editing,
deleting, searching, filtering and statistics are intentionally left out —
the brief says those are for the Final POE.

## How to run it

You'll need [Node.js](https://nodejs.org) and the free **Expo Go** app
(iOS/Android) or an emulator.

1. Unzip this project and open a terminal inside the folder.
2. Install the dependencies:
   ```
   npm install
   ```
3. Start the app:
   ```
   npm start
   ```
4. A QR code will appear in the terminal/browser. Scan it with the Expo Go
   app on your phone, or press `a` for an Android emulator / `i` for an iOS
   simulator if you have one set up.

## Project layout

```
App.tsx                        — root component, switches between the two screens
src/types.ts                   — the MenuItem shape (name, description, course, price)
src/theme.ts                   — shared colours/spacing so styling stays consistent
src/screens/MenuListScreen.tsx — home screen: FlatList + "+" button + empty state
src/screens/AddMenuItemScreen.tsx — form: TextInput, Picker, validation, confirmation
src/components/MenuItemCard.tsx   — one dish's card in the list
src/components/EmptyState.tsx     — "No dishes yet" message
```
